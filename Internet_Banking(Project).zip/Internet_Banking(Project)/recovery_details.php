<div  style="padding:100px;">
            <h2 style="text-align:center;color:#2E4372;"><u>Personal Details</u></h2>
			<br>
            <p><span class="pstext">Name: </span><?php echo $name;?></p>
			<hr><br>
            <p><span class="pstext">Date Of Birth: </span><?phpecho $dob;?></p>
			<hr><br>
			<p><span class="pstext">Mobile: </span><?php echo $mobile;?></p>
            <hr><br>
			<p><span class="pstext">Email: </span><?php echo $email;?></p>
            <hr><br>
			<p><span class="pstext">House No:</span><?php echo $hno;?></p>
            <hr><br>
			<p><span class="pstext">City: </span><?php echo $city;?></p>
            <hr><br>
			<p><span class="pstext">Account No: </span><?php echo $account_no;?></p>
            <hr><br>
			<p><span class="pstext">Branch: </span><?php echo $branch;?></p>
            <hr><br>
			<p><span class="pstext">Branch Code: </span><?php echo $branch_code;?></p>
			<hr><br>
		   <p><span class="pstext">Account Type: </span><?php echo $acc_type;?></p>
           <hr>
           </div>
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   	<div align="center">
			 <p><span class="pstext" > &nbsp;&nbsp;&nbsp;&nbsp;Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> <?php echo $name;?></p>
				<hr width="400px"><br><br>
		   <p><span class="pstext"">&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;Account No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </span><?php echo $account_no;?></p>
					<hr width="400px"><br><br>
			<p><span class="pstext">&nbsp;&nbsp;&nbsp;&nbsp;Branch&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><?php echo $brname;?></p>
             	<hr width="400px"><br><br>
			 <p><span class="pstext">Branch Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><?php echo $brcode;?></p>
             	<hr width="400px"><br><br>
			 <p><span  class="pstext">Balance INR&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><?php echo $accbal;?></p>
             	<hr width="400px"><br><br>
			 <p><span class="pstext">Account type&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><?php echo $acctype;?></p>
				<hr width="400px"><br><br>
			</div>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			                <p><span class="heading">Name: </span><?php echo $name;?></p>
            <p><span class="heading">Staff Id: </span><?php echo $id;?></p>
            <p><span class="heading">Email: </span><?php echo $email;?></p>
            <p><span class="heading">DOB: </span><?php echo $dob;?></p>
