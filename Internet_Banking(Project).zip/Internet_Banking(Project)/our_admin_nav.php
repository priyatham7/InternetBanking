
<div id="div1" style="margin:70px; float:left;height:700px;width:300px;">
<ul >
<li padding="10px">
<h2><br>Admin</h2>
<div><br>
<a href="admin_hompage.php">Admin Home</a>
</li>
<li>
<h2>
Profile<br></h2>
<div><br>
<a href="change_password.php">Change Password</a><br><br>
<a href="admin_logout.php">Logout</a>
</div>
</li>
</ul>
</div>
</div>


