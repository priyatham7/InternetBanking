
<div >
<div id="div1" style="margin:70px; float:left;height:700px;width:300px;">
<ul >
<li padding="10px">
<h2><br>Accounts</h2>
<div><br>
<a href="customer_account_summary.php">Account Summary</a><br><br>
<a href="customer_mini_statement.php">Mini Statement</a><br><br>
<a href="customer_account_statement.php">Account Statement</a><br></div>
</li>
<li><h2><br>
Fund Transfer</h2>
<div><br>
<a href="add_beneficiary.php">Add beneficiary</a><br><br>
<a href="display_beneficiary.php">View added Beneficiary</a><br><br>
<a href="customer_transfer.php">Transfer Funds</a><br>
</div>
</li>
<li><h2><br>
Requests</h2>
<div><br><br>
<a href="customer_issue_atm.php">Issue ATM card/Cheque book</a><br>
</div>
</li>
<li>
<h2><br>
Profile<br></h2>
<div><br><a href="customer_personal_details.php">Personal Details</a><br><br>
<a href="change_password_customer.php">Change Password</a><br><br>
<a href="customer_logout.php">Logout</a><br>
</div>
</li>
</ul>
</div>
</div>