
<body>
<div id="page" class="container">
	<div id="header">
		<div id="logo">
			<img src="duser.png" width="100px" alt="" />
			<h1 > <i><span style="font-size:30px;color:white;">WELCOME</span></i></h1>
			<br>
			<span ><b><i><?php echo "<span style='color:white;'>Admin</span>" ;?> </i></b></span>
		</div>
		 <div >
<div id="div1" style="margin:px; float:left;height:700px;width:300px;">
<ul >
<li padding="10px">
<h2 style="color:white;"><br><span style="font-size:30px;font-family:'times new roman'">Admin</span></h2>

<div><br><br><br><br>
<a href="admin_hompage.php">Admin Home</a><br><br>
<br><br>
</li>
<br>
<hr>
<li><h2  style="color:white;"><br><span style="font-size:30px;font-family:'times new roman'">
Profile</span></h2>
<div><br><br><br>
<a href="change_password.php">Change Password</a><br><br>
<a href="admin_logout.php">Logout</a><br><br>
</div>
<br>
<hr>
</li>
</ul>
</div>
</div>

	</div>
	<div id="main" background="white">
			<div style="margin-top:0px;margin-left:-14px;">
		<img src="pheader3.png">
		</div><br><br>
	
