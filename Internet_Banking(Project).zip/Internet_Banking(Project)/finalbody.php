
<body>
<div id="page" class="container">
	<div id="header">
		<div id="logo">
			<img src="duser.png" width="100px" alt="" />
			<h1 > <span style="color:white;font-family:Calibri;font-size:30px;">WELCOME</span></h1>
			<br>
			<span style="color:cyan;font-family:Exo;font-size:20px;"><b><?php echo $_SESSION['name'] ;?> </b></span>
		</div>
		 <div >
<div id="div1" style="margin:px; float:left;height:700px;width:300px;">
<ul >
<li padding="10px">
<h3 style="color:white;"><br><span style="font-size:30px;font-family:'times new roman'">Accounts</span></h2>

<div><br><br><br>
<a href="customer_account_summary.php">Account Summary</a><br><br>
<a href="customer_mini_statement.php">Mini Statement</a><br><br>
<a href="customer_account_statement.php">Account Statement</a><br></div>
<br><br>
<hr>
</li>
<li><h3  style="color:white;"><br><span style="font-size:30px;font-family:'times new roman'">
Fund Transfer</span></h2>
<div><br><br><br>
<a href="add_beneficiary.php">Add beneficiary</a><br><br>
<a href="display_beneficiary.php">View added Beneficiary</a><br><br>
<a href="customer_transfer.php">Transfer Funds</a><br><br><br>
</div>
<br>
<hr>
</li>
<li><h3 style="color:white;"><br><span style="font-size:30px;font-family:'times new roman'">
Requests</span></h2>
<div><br><br><br>
<a href="customer_issue_atm.php">Issue ATM card/Cheque book</a><br><br><br>
</div>
<br>
<hr>
</li>
<li>
<h3 style="color:white;"><br><span style="font-size:30px;font-family:'times new roman'">
Profile</span><br></h2>
<div><br><br><br><a href="customer_personal_details.php">Personal Details</a><br><br>
<a href="change_password_customer.php">Change Password</a><br><br>
<a href="customer_logout.php">Logout</a><br>
</div>
<br>
<hr>
</li>
</ul>
</div>
</div>

	</div>
	<div id="main" background="white">
		<div style="margin-top:0px;margin-left:-14px;">
		<img src="pheader3.png">
		</div><br>
	
